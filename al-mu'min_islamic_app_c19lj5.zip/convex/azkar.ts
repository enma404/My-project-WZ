import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getAzkarByCategory = query({
  args: { category: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("azkar")
      .withIndex("by_category", (q) => q.eq("category", args.category))
      .order("asc")
      .collect();
  },
});

export const getAllAzkar = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("azkar").order("asc").collect();
  },
});

// Seed data for azkar
export const seedAzkar = mutation({
  args: {},
  handler: async (ctx) => {
    const existingAzkar = await ctx.db.query("azkar").first();
    if (existingAzkar) return;

    const azkarData = [
      {
        category: "morning",
        title: {
          ar: "أعوذ بالله من الشيطان الرجيم",
          en: "I seek refuge in Allah from Satan the accursed",
          fr: "Je cherche refuge auprès d'Allah contre Satan le maudit",
          ru: "Прибегаю к защите Аллаха от проклятого шайтана"
        },
        text: {
          ar: "أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ",
          en: "A'udhu billahi min ash-shaytani'r-rajim",
          fr: "A'udhu billahi min ash-shaytani'r-rajim",
          ru: "А'узу биллахи мин аш-шайтани-р-раджим"
        },
        repetitions: 3,
        order: 1
      },
      {
        category: "morning",
        title: {
          ar: "آية الكرسي",
          en: "Ayat al-Kursi",
          fr: "Verset du Trône",
          ru: "Аят аль-Курси"
        },
        text: {
          ar: "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ",
          en: "Allah - there is no deity except Him, the Ever-Living, the Sustainer of existence. Neither drowsiness overtakes Him nor sleep. To Him belongs whatever is in the heavens and whatever is on the earth.",
          fr: "Allah - il n'y a de divinité que Lui, le Vivant, Celui qui subsiste par lui-même. Ni somnolence ni sommeil ne Le saisissent. A Lui appartient tout ce qui est dans les cieux et sur la terre.",
          ru: "Аллах - нет божества, кроме Него, Живого, Поддерживающего бытие. Не овладевает Им ни дремота, ни сон. Ему принадлежит то, что в небесах и на земле."
        },
        repetitions: 1,
        order: 2
      },
      {
        category: "evening",
        title: {
          ar: "سبحان الله وبحمده",
          en: "Glory be to Allah and praise be to Him",
          fr: "Gloire à Allah et louange à Lui",
          ru: "Слава Аллаху и хвала Ему"
        },
        text: {
          ar: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
          en: "Subhan Allah wa bihamdihi",
          fr: "Subhan Allah wa bihamdihi",
          ru: "Субхан Аллахи ва бихамдихи"
        },
        repetitions: 100,
        order: 1
      }
    ];

    for (const zikr of azkarData) {
      await ctx.db.insert("azkar", zikr);
    }
  },
});
