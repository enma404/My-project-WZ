import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const getTodaysTip = query({
  args: {},
  handler: async (ctx) => {
    const today = new Date().toISOString().split('T')[0];
    const tip = await ctx.db
      .query("dailyTips")
      .withIndex("by_date", (q) => q.eq("date", today))
      .first();
    
    if (!tip) {
      // Return a random tip if no specific tip for today
      const allTips = await ctx.db.query("dailyTips").collect();
      if (allTips.length === 0) return null;
      const randomIndex = Math.floor(Math.random() * allTips.length);
      return allTips[randomIndex];
    }
    
    return tip;
  },
});

export const seedDailyTips = mutation({
  args: {},
  handler: async (ctx) => {
    const existingTip = await ctx.db.query("dailyTips").first();
    if (existingTip) return;

    const today = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const tipsData = [
      {
        tip: {
          ar: "ابدأ يومك بذكر الله واستغفاره، فإن في ذلك بركة وطمأنينة للقلب",
          en: "Start your day with remembrance of Allah and seeking His forgiveness, for there is blessing and peace for the heart in that",
          fr: "Commencez votre journée par le rappel d'Allah et en demandant Son pardon, car il y a une bénédiction et une paix pour le cœur dans cela",
          ru: "Начинайте свой день с поминания Аллаха и просьбы о Его прощении, ибо в этом есть благословение и покой для сердца"
        },
        date: today,
        category: "morning"
      },
      {
        tip: {
          ar: "الصلاة في وقتها نور للقلب وراحة للروح، فحافظ عليها",
          en: "Prayer at its time is light for the heart and rest for the soul, so maintain it",
          fr: "La prière à son heure est une lumière pour le cœur et un repos pour l'âme, alors maintenez-la",
          ru: "Молитва в свое время - это свет для сердца и покой для души, поэтому соблюдайте ее"
        },
        date: tomorrow,
        category: "prayer"
      }
    ];

    for (const tip of tipsData) {
      await ctx.db.insert("dailyTips", tip);
    }
  },
});
