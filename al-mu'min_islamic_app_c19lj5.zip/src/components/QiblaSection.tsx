import { useState, useEffect } from "react";

interface QiblaSectionProps {
  language: string;
}

export function QiblaSection({ language }: QiblaSectionProps) {
  const [qiblaDirection, setQiblaDirection] = useState<number | null>(null);
  const [currentHeading, setCurrentHeading] = useState<number>(0);
  const [location, setLocation] = useState<{latitude: number, longitude: number} | null>(null);

  const translations = {
    en: {
      title: "Qibla Direction",
      finding: "Finding Qibla...",
      error: "Unable to determine location",
      allow: "Please allow location access",
      direction: "Qibla Direction",
      degrees: "degrees"
    },
    ar: {
      title: "اتجاه القبلة",
      finding: "البحث عن القبلة...",
      error: "غير قادر على تحديد الموقع",
      allow: "يرجى السماح بالوصول إلى الموقع",
      direction: "اتجاه القبلة",
      degrees: "درجة"
    },
    fr: {
      title: "Direction de la Qibla",
      finding: "Recherche de la Qibla...",
      error: "Impossible de déterminer l'emplacement",
      allow: "Veuillez autoriser l'accès à la localisation",
      direction: "Direction de la Qibla",
      degrees: "degrés"
    },
    ru: {
      title: "Направление Киблы",
      finding: "Поиск Киблы...",
      error: "Невозможно определить местоположение",
      allow: "Пожалуйста, разрешите доступ к местоположению",
      direction: "Направление Киблы",
      degrees: "градусов"
    }
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  useEffect(() => {
    // Get user location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocation({ latitude, longitude });
          
          // Calculate Qibla direction (simplified calculation)
          // Kaaba coordinates: 21.4225, 39.8262
          const kaabaLat = 21.4225;
          const kaabaLng = 39.8262;
          
          const dLng = (kaabaLng - longitude) * Math.PI / 180;
          const lat1 = latitude * Math.PI / 180;
          const lat2 = kaabaLat * Math.PI / 180;
          
          const y = Math.sin(dLng) * Math.cos(lat2);
          const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
          
          let bearing = Math.atan2(y, x) * 180 / Math.PI;
          bearing = (bearing + 360) % 360;
          
          setQiblaDirection(bearing);
        },
        (error) => {
          console.error("Error getting location:", error);
        }
      );
    }

    // Get device orientation
    const handleOrientation = (event: DeviceOrientationEvent) => {
      if (event.alpha !== null) {
        setCurrentHeading(event.alpha);
      }
    };

    if (window.DeviceOrientationEvent) {
      window.addEventListener('deviceorientation', handleOrientation);
    }

    return () => {
      if (window.DeviceOrientationEvent) {
        window.removeEventListener('deviceorientation', handleOrientation);
      }
    };
  }, []);

  const compassRotation = qiblaDirection !== null ? qiblaDirection - currentHeading : 0;

  return (
    <div className="space-y-6 pb-20">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{t.title}</h2>
      </div>

      {qiblaDirection === null ? (
        <div className="bg-white dark:bg-gray-800 rounded-lg p-8 shadow-sm text-center">
          <div className="animate-spin w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">{t.finding}</p>
          <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">{t.allow}</p>
        </div>
      ) : (
        <>
          {/* Compass */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-8 shadow-sm">
            <div className="relative w-64 h-64 mx-auto">
              {/* Compass Background */}
              <div className="absolute inset-0 rounded-full border-4 border-gray-300 dark:border-gray-600 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-800">
                {/* Compass Markings */}
                <div className="absolute inset-2 rounded-full border border-gray-200 dark:border-gray-600">
                  {/* North Marker */}
                  <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1 w-1 h-6 bg-red-500"></div>
                  {/* Cardinal Directions */}
                  <div className="absolute top-2 left-1/2 transform -translate-x-1/2 text-xs font-bold text-red-500">N</div>
                  <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-xs font-bold text-gray-600 dark:text-gray-400">S</div>
                  <div className="absolute left-2 top-1/2 transform -translate-y-1/2 text-xs font-bold text-gray-600 dark:text-gray-400">W</div>
                  <div className="absolute right-2 top-1/2 transform -translate-y-1/2 text-xs font-bold text-gray-600 dark:text-gray-400">E</div>
                </div>
              </div>
              
              {/* Qibla Arrow */}
              <div 
                className="absolute inset-0 flex items-center justify-center transition-transform duration-300"
                style={{ transform: `rotate(${compassRotation}deg)` }}
              >
                <div className="w-1 h-20 bg-emerald-500 rounded-full relative">
                  <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-b-8 border-l-transparent border-r-transparent border-b-emerald-500"></div>
                  <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-emerald-500 rounded-full"></div>
                </div>
              </div>
              
              {/* Center Dot */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-emerald-600 rounded-full border-2 border-white"></div>
            </div>
          </div>

          {/* Direction Info */}
          <div className="bg-emerald-50 dark:bg-emerald-900 rounded-lg p-4 shadow-sm">
            <div className="text-center space-y-2">
              <p className="text-sm text-emerald-700 dark:text-emerald-300 font-medium">{t.direction}</p>
              <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">
                {Math.round(qiblaDirection)}° {t.degrees}
              </p>
              <div className="flex items-center justify-center space-x-2 text-sm text-emerald-600 dark:text-emerald-400">
                <span>🕌</span>
                <span>Kaaba, Mecca</span>
              </div>
            </div>
          </div>

          {/* Instructions */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
            <div className="text-center text-sm text-gray-600 dark:text-gray-400">
              <p>📱 Hold your device flat and point the green arrow towards the Qibla</p>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
