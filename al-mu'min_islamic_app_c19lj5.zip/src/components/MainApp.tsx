import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Navigation } from "./Navigation";
import { AzkarSection } from "./AzkarSection";
import { HadithSection } from "./HadithSection";
import { DailyTipsSection } from "./DailyTipsSection";
import { TasbeehSection } from "./TasbeehSection";
import { QiblaSection } from "./QiblaSection";
import { PrayerTimesSection } from "./PrayerTimesSection";
import { SettingsSection } from "./SettingsSection";
import { SignOutButton } from "../SignOutButton";

type Section = 'azkar' | 'hadith' | 'tips' | 'tasbeeh' | 'qibla' | 'prayer' | 'settings';

export function MainApp() {
  const [activeSection, setActiveSection] = useState<Section>('azkar');
  const userSettings = useQuery(api.userSettings.getUserSettings);
  const seedAzkar = useMutation(api.azkar.seedAzkar);
  const seedHadith = useMutation(api.hadith.seedHadith);
  const seedTips = useMutation(api.dailyTips.seedDailyTips);

  // Seed data on first load
  useState(() => {
    seedAzkar();
    seedHadith();
    seedTips();
  });

  const language = userSettings?.language || 'en';

  const translations = {
    en: {
      title: "Al-Mu'min",
      subtitle: "Your Islamic Companion"
    },
    ar: {
      title: "المؤمن",
      subtitle: "رفيقك الإسلامي"
    },
    fr: {
      title: "Al-Mu'min",
      subtitle: "Votre Compagnon Islamique"
    },
    ru: {
      title: "Аль-Муъмин",
      subtitle: "Ваш исламский спутник"
    }
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  const renderSection = () => {
    switch (activeSection) {
      case 'azkar':
        return <AzkarSection language={language} />;
      case 'hadith':
        return <HadithSection language={language} />;
      case 'tips':
        return <DailyTipsSection language={language} />;
      case 'tasbeeh':
        return <TasbeehSection language={language} />;
      case 'qibla':
        return <QiblaSection language={language} />;
      case 'prayer':
        return <PrayerTimesSection language={language} />;
      case 'settings':
        return <SettingsSection language={language} />;
      default:
        return <AzkarSection language={language} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-100 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <header className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-b border-emerald-200 dark:border-gray-700 sticky top-0 z-50">
        <div className="max-w-md mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full flex items-center justify-center">
              <span className="text-white text-sm">☪</span>
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-800 dark:text-white">{t.title}</h1>
              <p className="text-xs text-gray-600 dark:text-gray-300">{t.subtitle}</p>
            </div>
          </div>
          <SignOutButton />
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto px-4 py-6">
        {renderSection()}
      </main>

      {/* Bottom Navigation */}
      <Navigation activeSection={activeSection} onSectionChange={setActiveSection} language={language} />
    </div>
  );
}
