import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface AzkarSectionProps {
  language: string;
}

export function AzkarSection({ language }: AzkarSectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<'morning' | 'evening'>('morning');
  const azkar = useQuery(api.azkar.getAzkarByCategory, { category: selectedCategory });

  const translations = {
    en: {
      title: "Azkar & Supplications",
      morning: "Morning Azkar",
      evening: "Evening Azkar",
      repetitions: "Repeat"
    },
    ar: {
      title: "الأذكار والأدعية",
      morning: "أذكار الصباح",
      evening: "أذكار المساء",
      repetitions: "مرات"
    },
    fr: {
      title: "Azkar et Supplications",
      morning: "Azkar du Matin",
      evening: "Azkar du Soir",
      repetitions: "Répéter"
    },
    ru: {
      title: "Азкар и Мольбы",
      morning: "Утренний Азкар",
      evening: "Вечерний Азкар",
      repetitions: "Повторить"
    }
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  return (
    <div className="space-y-6 pb-20">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{t.title}</h2>
        
        {/* Category Selector */}
        <div className="flex bg-white dark:bg-gray-800 rounded-lg p-1 shadow-sm">
          <button
            onClick={() => setSelectedCategory('morning')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              selectedCategory === 'morning'
                ? 'bg-emerald-500 text-white'
                : 'text-gray-600 dark:text-gray-400 hover:text-emerald-600'
            }`}
          >
            {t.morning}
          </button>
          <button
            onClick={() => setSelectedCategory('evening')}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              selectedCategory === 'evening'
                ? 'bg-emerald-500 text-white'
                : 'text-gray-600 dark:text-gray-400 hover:text-emerald-600'
            }`}
          >
            {t.evening}
          </button>
        </div>
      </div>

      {/* Azkar List */}
      <div className="space-y-4">
        {azkar?.map((zikr) => (
          <div key={zikr._id} className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-emerald-100 dark:border-gray-700">
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-3">
              {zikr.title[language as keyof typeof zikr.title] || zikr.title.en}
            </h3>
            
            <div className="space-y-3">
              <p className="text-xl leading-relaxed text-gray-700 dark:text-gray-300 font-arabic">
                {zikr.text[language as keyof typeof zikr.text] || zikr.text.ar}
              </p>
              
              {zikr.repetitions && (
                <div className="flex items-center justify-between pt-3 border-t border-emerald-100 dark:border-gray-700">
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    {t.repetitions}: {zikr.repetitions}x
                  </span>
                  <div className="w-8 h-8 bg-emerald-100 dark:bg-emerald-900 rounded-full flex items-center justify-center">
                    <span className="text-emerald-600 dark:text-emerald-400 text-sm font-bold">
                      {zikr.repetitions}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
