import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";

interface TasbeehSectionProps {
  language: string;
}

export function TasbeehSection({ language }: TasbeehSectionProps) {
  const [count, setCount] = useState(0);
  const [selectedPhrase, setSelectedPhrase] = useState(0);
  const saveTasbeehSession = useMutation(api.tasbeeh.saveTasbeehSession);

  const translations = {
    en: {
      title: "Digital Tasbeeh",
      count: "Count",
      reset: "Reset",
      save: "Save Session",
      phrases: [
        "Subhan Allah (Glory be to Allah)",
        "Alhamdulillah (Praise be to Allah)",
        "Allahu Akbar (Allah is Greatest)",
        "La ilaha illa Allah (There is no god but Allah)"
      ]
    },
    ar: {
      title: "التسبيح الرقمي",
      count: "العدد",
      reset: "إعادة تعيين",
      save: "حفظ الجلسة",
      phrases: [
        "سبحان الله",
        "الحمد لله",
        "الله أكبر",
        "لا إله إلا الله"
      ]
    },
    fr: {
      title: "Tasbeeh Numérique",
      count: "Compte",
      reset: "Réinitialiser",
      save: "Sauvegarder la Session",
      phrases: [
        "Subhan Allah (Gloire à Allah)",
        "Alhamdulillah (Louange à Allah)",
        "Allahu Akbar (Allah est le Plus Grand)",
        "La ilaha illa Allah (Il n'y a de dieu qu'Allah)"
      ]
    },
    ru: {
      title: "Цифровой Тасбих",
      count: "Счет",
      reset: "Сброс",
      save: "Сохранить Сессию",
      phrases: [
        "Субхан Аллах (Слава Аллаху)",
        "Альхамдулиллах (Хвала Аллаху)",
        "Аллаху Акбар (Аллах Велик)",
        "Ля иляха илля Ллах (Нет бога кроме Аллаха)"
      ]
    }
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  const increment = () => {
    setCount(count + 1);
  };

  const reset = () => {
    setCount(0);
  };

  const saveSession = async () => {
    if (count > 0) {
      await saveTasbeehSession({
        count,
        phrase: t.phrases[selectedPhrase]
      });
      setCount(0);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{t.title}</h2>
      </div>

      {/* Phrase Selector */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
        <div className="space-y-2">
          {t.phrases.map((phrase, index) => (
            <button
              key={index}
              onClick={() => setSelectedPhrase(index)}
              className={`w-full p-3 rounded-lg text-left transition-colors ${
                selectedPhrase === index
                  ? 'bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300 border-2 border-emerald-300'
                  : 'bg-gray-50 dark:bg-gray-700 text-gray-700 dark:text-gray-300 border-2 border-transparent hover:bg-emerald-50 dark:hover:bg-emerald-900'
              }`}
            >
              <span className="text-sm font-medium">{phrase}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Counter Display */}
      <div className="bg-gradient-to-br from-emerald-100 to-teal-100 dark:from-emerald-900 dark:to-teal-900 rounded-lg p-8 shadow-sm text-center">
        <div className="space-y-4">
          <p className="text-lg font-medium text-gray-700 dark:text-gray-300">
            {t.phrases[selectedPhrase]}
          </p>
          <div className="text-6xl font-bold text-emerald-600 dark:text-emerald-400">
            {count}
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-400">{t.count}</p>
        </div>
      </div>

      {/* Counter Button */}
      <button
        onClick={increment}
        className="w-full bg-emerald-500 hover:bg-emerald-600 active:bg-emerald-700 text-white py-6 rounded-lg text-xl font-semibold transition-colors shadow-lg"
      >
        +1
      </button>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-4">
        <button
          onClick={reset}
          className="bg-gray-500 hover:bg-gray-600 text-white py-3 rounded-lg font-medium transition-colors"
        >
          {t.reset}
        </button>
        <button
          onClick={saveSession}
          disabled={count === 0}
          className="bg-blue-500 hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white py-3 rounded-lg font-medium transition-colors"
        >
          {t.save}
        </button>
      </div>
    </div>
  );
}
