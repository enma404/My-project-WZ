import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface HadithSectionProps {
  language: string;
}

export function HadithSection({ language }: HadithSectionProps) {
  const hadith = useQuery(api.hadith.getRandomHadith);

  const translations = {
    en: {
      title: "Prophetic Hadith",
      narrator: "Narrator",
      source: "Source",
      refresh: "New Hadith"
    },
    ar: {
      title: "الحديث النبوي",
      narrator: "الراوي",
      source: "المصدر",
      refresh: "حديث جديد"
    },
    fr: {
      title: "Hadith Prophétique",
      narrator: "Narrateur",
      source: "Source",
      refresh: "Nouveau Hadith"
    },
    ru: {
      title: "Пророческий Хадис",
      narrator: "Рассказчик",
      source: "Источник",
      refresh: "Новый Хадис"
    }
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  const refreshHadith = () => {
    window.location.reload();
  };

  if (!hadith) {
    return (
      <div className="space-y-6 pb-20">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{t.title}</h2>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{t.title}</h2>
        <button
          onClick={refreshHadith}
          className="bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
        >
          {t.refresh}
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-emerald-100 dark:border-gray-700">
        <div className="space-y-4">
          <p className="text-lg leading-relaxed text-gray-700 dark:text-gray-300 font-arabic">
            {hadith.text[language as keyof typeof hadith.text] || hadith.text.ar}
          </p>
          
          <div className="pt-4 border-t border-emerald-100 dark:border-gray-700 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-400">{t.narrator}:</span>
              <span className="text-gray-800 dark:text-gray-200 font-medium">{hadith.narrator}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-400">{t.source}:</span>
              <span className="text-gray-800 dark:text-gray-200 font-medium">
                {hadith.source[language as keyof typeof hadith.source] || hadith.source.ar}
              </span>
            </div>
            {hadith.isAuthentic && (
              <div className="flex items-center justify-center pt-2">
                <span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-3 py-1 rounded-full text-xs font-medium">
                  ✓ Authentic
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
