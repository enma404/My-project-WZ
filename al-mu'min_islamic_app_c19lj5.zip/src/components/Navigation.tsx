interface NavigationProps {
  activeSection: string;
  onSectionChange: (section: any) => void;
  language: string;
}

export function Navigation({ activeSection, onSectionChange, language }: NavigationProps) {
  const translations = {
    en: {
      azkar: "Azkar",
      hadith: "Hadith", 
      tips: "Tips",
      tasbeeh: "Tasbeeh",
      qibla: "Qibla",
      prayer: "Prayer",
      settings: "Settings"
    },
    ar: {
      azkar: "أذكار",
      hadith: "حديث",
      tips: "نصائح",
      tasbeeh: "تسبيح",
      qibla: "قبلة",
      prayer: "صلاة",
      settings: "إعدادات"
    },
    fr: {
      azkar: "Azkar",
      hadith: "Hadith",
      tips: "Conseils",
      tasbeeh: "Tasbeeh",
      qibla: "Qibla",
      prayer: "Prière",
      settings: "Paramètres"
    },
    ru: {
      azkar: "Азкар",
      hadith: "Хадис",
      tips: "Советы",
      tasbeeh: "Тасбих",
      qibla: "Кибла",
      prayer: "Молитва",
      settings: "Настройки"
    }
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  const navItems = [
    { id: 'azkar', icon: '📿', label: t.azkar },
    { id: 'hadith', icon: '📖', label: t.hadith },
    { id: 'tips', icon: '💡', label: t.tips },
    { id: 'tasbeeh', icon: '🔢', label: t.tasbeeh },
    { id: 'qibla', icon: '🧭', label: t.qibla },
    { id: 'prayer', icon: '🕌', label: t.prayer },
    { id: 'settings', icon: '⚙️', label: t.settings },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border-t border-emerald-200 dark:border-gray-700">
      <div className="max-w-md mx-auto px-2 py-2">
        <div className="flex justify-around">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onSectionChange(item.id)}
              className={`flex flex-col items-center p-2 rounded-lg transition-colors ${
                activeSection === item.id
                  ? 'bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300'
                  : 'text-gray-600 dark:text-gray-400 hover:text-emerald-600 dark:hover:text-emerald-400'
              }`}
            >
              <span className="text-lg mb-1">{item.icon}</span>
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}
