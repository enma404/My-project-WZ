import { useState, useEffect } from "react";
import { useAction } from "convex/react";
import { api } from "../../convex/_generated/api";

interface PrayerTimesSectionProps {
  language: string;
}

interface PrayerTimes {
  fajr: string;
  sunrise: string;
  dhuhr: string;
  asr: string;
  maghrib: string;
  isha: string;
  date: string;
}

export function PrayerTimesSection({ language }: PrayerTimesSectionProps) {
  const [prayerTimes, setPrayerTimes] = useState<PrayerTimes | null>(null);
  const [location, setLocation] = useState<string>("");
  const getPrayerTimes = useAction(api.prayerTimes.getPrayerTimes);

  const translations = {
    en: {
      title: "Prayer Times",
      fajr: "Fajr",
      sunrise: "Sunrise",
      dhuhr: "Dhuhr",
      asr: "Asr",
      maghrib: "Maghrib",
      isha: "Isha",
      loading: "Loading prayer times...",
      location: "Location",
      today: "Today"
    },
    ar: {
      title: "أوقات الصلاة",
      fajr: "الفجر",
      sunrise: "الشروق",
      dhuhr: "الظهر",
      asr: "العصر",
      maghrib: "المغرب",
      isha: "العشاء",
      loading: "تحميل أوقات الصلاة...",
      location: "الموقع",
      today: "اليوم"
    },
    fr: {
      title: "Heures de Prière",
      fajr: "Fajr",
      sunrise: "Lever du soleil",
      dhuhr: "Dhuhr",
      asr: "Asr",
      maghrib: "Maghrib",
      isha: "Isha",
      loading: "Chargement des heures de prière...",
      location: "Emplacement",
      today: "Aujourd'hui"
    },
    ru: {
      title: "Время Молитв",
      fajr: "Фаджр",
      sunrise: "Восход",
      dhuhr: "Зухр",
      asr: "Аср",
      maghrib: "Магриб",
      isha: "Иша",
      loading: "Загрузка времени молитв...",
      location: "Местоположение",
      today: "Сегодня"
    }
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          setLocation(`${latitude.toFixed(2)}, ${longitude.toFixed(2)}`);
          
          try {
            const times = await getPrayerTimes({ latitude, longitude });
            setPrayerTimes(times);
          } catch (error) {
            console.error("Error fetching prayer times:", error);
          }
        },
        (error) => {
          console.error("Error getting location:", error);
          // Set default prayer times if location is not available
          setPrayerTimes({
            fajr: "05:30",
            sunrise: "06:45",
            dhuhr: "12:30",
            asr: "15:45",
            maghrib: "18:15",
            isha: "19:30",
            date: new Date().toISOString().split('T')[0]
          });
        }
      );
    }
  }, [getPrayerTimes]);

  const getCurrentPrayer = () => {
    if (!prayerTimes) return null;
    
    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();
    
    const prayers = [
      { name: 'fajr', time: prayerTimes.fajr },
      { name: 'sunrise', time: prayerTimes.sunrise },
      { name: 'dhuhr', time: prayerTimes.dhuhr },
      { name: 'asr', time: prayerTimes.asr },
      { name: 'maghrib', time: prayerTimes.maghrib },
      { name: 'isha', time: prayerTimes.isha },
    ];

    for (let i = 0; i < prayers.length; i++) {
      const [hours, minutes] = prayers[i].time.split(':').map(Number);
      const prayerTime = hours * 60 + minutes;
      
      if (currentTime < prayerTime) {
        return prayers[i].name;
      }
    }
    
    return 'fajr'; // Next day's Fajr
  };

  const currentPrayer = getCurrentPrayer();

  if (!prayerTimes) {
    return (
      <div className="space-y-6 pb-20">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{t.title}</h2>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-lg p-8 shadow-sm text-center">
          <div className="animate-spin w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">{t.loading}</p>
        </div>
      </div>
    );
  }

  const prayerList = [
    { key: 'fajr', name: t.fajr, time: prayerTimes.fajr, icon: '🌅' },
    { key: 'sunrise', name: t.sunrise, time: prayerTimes.sunrise, icon: '☀️' },
    { key: 'dhuhr', name: t.dhuhr, time: prayerTimes.dhuhr, icon: '🌞' },
    { key: 'asr', name: t.asr, time: prayerTimes.asr, icon: '🌤️' },
    { key: 'maghrib', name: t.maghrib, time: prayerTimes.maghrib, icon: '🌅' },
    { key: 'isha', name: t.isha, time: prayerTimes.isha, icon: '🌙' },
  ];

  return (
    <div className="space-y-6 pb-20">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{t.title}</h2>
        <div className="inline-flex items-center bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300 px-3 py-1 rounded-full text-sm">
          <span className="mr-2">📅</span>
          {t.today} - {new Date().toLocaleDateString()}
        </div>
      </div>

      {/* Location */}
      {location && (
        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm text-center">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            {t.location}: {location}
          </p>
        </div>
      )}

      {/* Prayer Times List */}
      <div className="space-y-3">
        {prayerList.map((prayer) => (
          <div
            key={prayer.key}
            className={`bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border-2 transition-colors ${
              currentPrayer === prayer.key
                ? 'border-emerald-300 dark:border-emerald-600 bg-emerald-50 dark:bg-emerald-900'
                : 'border-transparent'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{prayer.icon}</span>
                <div>
                  <h3 className="font-semibold text-gray-800 dark:text-white">
                    {prayer.name}
                  </h3>
                  {currentPrayer === prayer.key && (
                    <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                      Next Prayer
                    </span>
                  )}
                </div>
              </div>
              <div className="text-right">
                <p className="text-xl font-bold text-gray-800 dark:text-white">
                  {prayer.time}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Note */}
      <div className="bg-blue-50 dark:bg-blue-900 rounded-lg p-4 shadow-sm">
        <div className="text-center text-sm text-blue-700 dark:text-blue-300">
          <p>🕌 Prayer times are calculated based on your location</p>
        </div>
      </div>
    </div>
  );
}
