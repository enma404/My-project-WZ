import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState, useEffect } from "react";
import { MainApp } from "./components/MainApp";

export default function App() {
  const [darkMode, setDarkMode] = useState(false);
  const userSettings = useQuery(api.userSettings.getUserSettings);

  useEffect(() => {
    if (userSettings?.darkMode !== undefined) {
      setDarkMode(userSettings.darkMode);
    }
  }, [userSettings]);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  return (
    <div className={`min-h-screen ${darkMode ? 'dark' : ''}`}>
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-100 dark:from-gray-900 dark:to-gray-800 transition-colors duration-300">
        <Authenticated>
          <MainApp />
        </Authenticated>
        
        <Unauthenticated>
          <div className="min-h-screen flex items-center justify-center p-4">
            <div className="w-full max-w-md">
              <div className="text-center mb-8">
                <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full flex items-center justify-center">
                  <span className="text-2xl text-white">☪</span>
                </div>
                <h1 className="text-4xl font-bold text-gray-800 dark:text-white mb-2">Al-Mu'min</h1>
                <p className="text-gray-600 dark:text-gray-300">المؤمن - Your Islamic Companion</p>
              </div>
              <SignInForm />
            </div>
          </div>
        </Unauthenticated>
        
        <Toaster />
      </div>
    </div>
  );
}
