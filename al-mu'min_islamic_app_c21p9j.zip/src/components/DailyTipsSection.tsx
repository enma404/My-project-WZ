import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface DailyTipsSectionProps {
  language: string;
}

export function DailyTipsSection({ language }: DailyTipsSectionProps) {
  const todaysTip = useQuery(api.dailyTips.getTodaysTip);

  const translations = {
    en: {
      title: "Daily Islamic Tips",
      todaysWisdom: "Today's Wisdom",
      date: "Date"
    },
    ar: {
      title: "النصائح الإسلامية اليومية",
      todaysWisdom: "حكمة اليوم",
      date: "التاريخ"
    },
    fr: {
      title: "Conseils Islamiques Quotidiens",
      todaysWisdom: "Sagesse du Jour",
      date: "Date"
    },
    ru: {
      title: "Ежедневные исламские советы",
      todaysWisdom: "Мудрость дня",
      date: "Дата"
    }
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  if (!todaysTip) {
    return (
      <div className="space-y-6 pb-20">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{t.title}</h2>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{t.title}</h2>
        <div className="inline-flex items-center bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300 px-3 py-1 rounded-full text-sm">
          <span className="mr-2">💡</span>
          {t.todaysWisdom}
        </div>
      </div>

      <div className="bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-gray-800 dark:to-gray-700 rounded-lg p-6 shadow-sm border border-emerald-200 dark:border-gray-600">
        <div className="space-y-4">
          <p className="text-lg leading-relaxed text-gray-700 dark:text-gray-300 text-center">
            {todaysTip.tip[language as keyof typeof todaysTip.tip] || todaysTip.tip.en}
          </p>
          
          <div className="pt-4 border-t border-emerald-200 dark:border-gray-600 text-center">
            <span className="text-sm text-gray-600 dark:text-gray-400">
              {t.date}: {new Date().toLocaleDateString()}
            </span>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-emerald-100 dark:border-gray-700">
        <div className="text-center text-sm text-gray-600 dark:text-gray-400">
          <p>🔔 Enable notifications to receive daily tips</p>
        </div>
      </div>
    </div>
  );
}
