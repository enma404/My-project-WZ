import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface SettingsSectionProps {
  language: string;
}

export function SettingsSection({ language }: SettingsSectionProps) {
  const userSettings = useQuery(api.userSettings.getUserSettings);
  const updateSettings = useMutation(api.userSettings.updateUserSettings);

  const translations = {
    en: {
      title: "Settings",
      language: "Language",
      darkMode: "Dark Mode",
      notifications: "Notifications",
      languages: {
        en: "English",
        ar: "العربية",
        fr: "Français",
        ru: "Русский"
      }
    },
    ar: {
      title: "الإعدادات",
      language: "اللغة",
      darkMode: "الوضع المظلم",
      notifications: "الإشعارات",
      languages: {
        en: "English",
        ar: "العربية",
        fr: "Français",
        ru: "Русский"
      }
    },
    fr: {
      title: "Paramètres",
      language: "Langue",
      darkMode: "Mode Sombre",
      notifications: "Notifications",
      languages: {
        en: "English",
        ar: "العربية",
        fr: "Français",
        ru: "Русский"
      }
    },
    ru: {
      title: "Настройки",
      language: "Язык",
      darkMode: "Темный режим",
      notifications: "Уведомления",
      languages: {
        en: "English",
        ar: "العربية",
        fr: "Français",
        ru: "Русский"
      }
    }
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  const handleLanguageChange = async (newLanguage: string) => {
    await updateSettings({ language: newLanguage });
    window.location.reload(); // Reload to apply language change
  };

  const handleDarkModeToggle = async () => {
    await updateSettings({ darkMode: !userSettings?.darkMode });
  };

  const handleNotificationsToggle = async () => {
    await updateSettings({ notificationsEnabled: !userSettings?.notificationsEnabled });
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{t.title}</h2>
      </div>

      {/* Language Setting */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">{t.language}</h3>
        <div className="grid grid-cols-2 gap-3">
          {Object.entries(t.languages).map(([code, name]) => (
            <button
              key={code}
              onClick={() => handleLanguageChange(code)}
              className={`p-3 rounded-lg text-center transition-colors ${
                userSettings?.language === code
                  ? 'bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300 border-2 border-emerald-300'
                  : 'bg-gray-50 dark:bg-gray-700 text-gray-700 dark:text-gray-300 border-2 border-transparent hover:bg-emerald-50 dark:hover:bg-emerald-900'
              }`}
            >
              {name}
            </button>
          ))}
        </div>
      </div>

      {/* Dark Mode Setting */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white">{t.darkMode}</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">Toggle dark/light theme</p>
          </div>
          <button
            onClick={handleDarkModeToggle}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
              userSettings?.darkMode ? 'bg-emerald-600' : 'bg-gray-200'
            }`}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                userSettings?.darkMode ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Notifications Setting */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-800 dark:text-white">{t.notifications}</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">Daily tips and reminders</p>
          </div>
          <button
            onClick={handleNotificationsToggle}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
              userSettings?.notificationsEnabled ? 'bg-emerald-600' : 'bg-gray-200'
            }`}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                userSettings?.notificationsEnabled ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>
      </div>

      {/* App Info */}
      <div className="bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-gray-800 dark:to-gray-700 rounded-lg p-6 shadow-sm text-center">
        <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full flex items-center justify-center">
          <span className="text-2xl text-white">☪</span>
        </div>
        <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">Al-Mu'min</h3>
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">المؤمن - Your Islamic Companion</p>
        <p className="text-xs text-gray-500 dark:text-gray-500">Version 1.0.0</p>
      </div>
    </div>
  );
}
