// Islamic App JavaScript
class IslamicApp {
  constructor() {
    this.currentLanguage = localStorage.getItem('language') || 'en';
    this.currentTheme = localStorage.getItem('theme') || 'light';
    this.currentSection = 'azkar';
    this.currentAzkarCategory = 'morning';
    this.tasbeehCount = 0;
    this.currentPhrase = 'سبحان الله';
    this.currentHadithIndex = 0;
    this.currentTipIndex = 0;
    this.userLocation = null;
    this.qiblaDirection = 0;

    this.init();
  }

  init() {
    this.setupEventListeners();
    this.applyTheme();
    this.updateLanguage();
    this.showSection(this.currentSection);
    this.loadAzkar();
    this.loadHadith();
    this.loadDailyTip();
    this.loadPrayerTimes();
    this.setupQibla();
    this.updateDateTime();
    
    // Update time every minute
    setInterval(() => this.updateDateTime(), 60000);
  }

  setupEventListeners() {
    // Navigation
    document.querySelectorAll('.nav-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const section = e.currentTarget.dataset.section;
        this.showSection(section);
      });
    });

    // Theme toggle
    document.getElementById('theme-toggle').addEventListener('click', () => {
      this.toggleTheme();
    });

    document.getElementById('dark-mode-toggle').addEventListener('change', (e) => {
      this.currentTheme = e.target.checked ? 'dark' : 'light';
      this.applyTheme();
      localStorage.setItem('theme', this.currentTheme);
    });

    // Language selection
    document.querySelectorAll('.lang-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        this.changeLanguage(e.currentTarget.dataset.lang);
      });
    });

    // Azkar category tabs
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        this.changeAzkarCategory(e.currentTarget.dataset.category);
      });
    });

    // Hadith refresh
    document.getElementById('new-hadith-btn').addEventListener('click', () => {
      this.loadRandomHadith();
    });

    // Tasbeeh
    document.getElementById('tasbeeh-btn').addEventListener('click', () => {
      this.incrementTasbeeh();
    });

    document.getElementById('reset-btn').addEventListener('click', () => {
      this.resetTasbeeh();
    });

    document.querySelectorAll('.phrase-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        this.changePhrase(e.currentTarget.dataset.phrase);
      });
    });
  }

  showSection(sectionName) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
      section.classList.remove('active');
    });

    // Show selected section
    document.getElementById(`${sectionName}-section`).classList.add('active');

    // Update navigation
    document.querySelectorAll('.nav-btn').forEach(btn => {
      btn.classList.remove('active');
    });
    document.querySelector(`[data-section="${sectionName}"]`).classList.add('active');

    this.currentSection = sectionName;
  }

  toggleTheme() {
    this.currentTheme = this.currentTheme === 'light' ? 'dark' : 'light';
    this.applyTheme();
    localStorage.setItem('theme', this.currentTheme);
  }

  applyTheme() {
    if (this.currentTheme === 'dark') {
      document.documentElement.setAttribute('data-theme', 'dark');
      document.getElementById('theme-toggle').textContent = '☀️';
      document.getElementById('dark-mode-toggle').checked = true;
    } else {
      document.documentElement.removeAttribute('data-theme');
      document.getElementById('theme-toggle').textContent = '🌙';
      document.getElementById('dark-mode-toggle').checked = false;
    }
  }

  changeLanguage(lang) {
    this.currentLanguage = lang;
    localStorage.setItem('language', lang);
    
    // Update language buttons
    document.querySelectorAll('.lang-btn').forEach(btn => {
      btn.classList.remove('active');
    });
    document.querySelector(`[data-lang="${lang}"]`).classList.add('active');

    this.updateLanguage();
    this.loadAzkar();
    this.loadHadith();
    this.loadDailyTip();
  }

  updateLanguage() {
    const t = islamicData.translations[this.currentLanguage];
    
    // Update static text elements
    document.getElementById('app-title').textContent = t.appTitle;
    document.getElementById('app-subtitle').textContent = t.appSubtitle;
    
    // Update section titles
    document.getElementById('azkar-title').textContent = t.azkar;
    document.getElementById('hadith-title').textContent = t.hadith;
    document.getElementById('tips-title').textContent = t.dailyTips;
    document.getElementById('tasbeeh-title').textContent = t.tasbeeh;
    document.getElementById('qibla-title').textContent = t.qiblaDirection;
    document.getElementById('prayer-title').textContent = t.prayerTimes;
    document.getElementById('settings-title').textContent = t.settings;

    // Update navigation labels
    document.getElementById('nav-azkar').textContent = t.azkar;
    document.getElementById('nav-hadith').textContent = t.hadith;
    document.getElementById('nav-tips').textContent = t.tips;
    document.getElementById('nav-tasbeeh').textContent = t.tasbeeh;
    document.getElementById('nav-qibla').textContent = t.qibla;
    document.getElementById('nav-prayer').textContent = t.prayer;
    document.getElementById('nav-settings').textContent = t.settings;

    // Update category tabs
    document.getElementById('morning-tab').textContent = t.morning;
    document.getElementById('evening-tab').textContent = t.evening;
    document.getElementById('general-tab').textContent = t.general;

    // Update settings
    document.getElementById('language-setting').textContent = t.language;
    document.getElementById('dark-mode-setting').textContent = t.darkMode;
    document.getElementById('dark-mode-desc').textContent = t.darkModeDesc;
    document.getElementById('notifications-setting').textContent = t.notifications;
    document.getElementById('notifications-desc').textContent = t.notificationsDesc;

    // Update direction for Arabic
    if (lang === 'ar') {
      document.documentElement.setAttribute('dir', 'rtl');
    } else {
      document.documentElement.setAttribute('dir', 'ltr');
    }
  }

  changeAzkarCategory(category) {
    this.currentAzkarCategory = category;
    
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.classList.remove('active');
    });
    document.querySelector(`[data-category="${category}"]`).classList.add('active');

    this.loadAzkar();
  }

  loadAzkar() {
    const azkarList = islamicData.azkar[this.currentAzkarCategory];
    const container = document.getElementById('azkar-content');
    const t = islamicData.translations[this.currentLanguage];
    
    container.innerHTML = '';

    azkarList.forEach(zikr => {
      const card = document.createElement('div');
      card.className = 'azkar-card';
      
      card.innerHTML = `
        <div class="azkar-arabic font-arabic">${zikr.text.ar}</div>
        <div class="azkar-translation">${zikr.text[this.currentLanguage]}</div>
        <div class="azkar-repetitions">
          <span>🔢</span>
          ${zikr.repetitions} ${t.repetitions}
        </div>
      `;
      
      container.appendChild(card);
    });
  }

  loadHadith() {
    const hadith = islamicData.hadith[this.currentHadithIndex];
    const container = document.getElementById('hadith-content');
    
    container.innerHTML = `
      <div class="hadith-arabic font-arabic">${hadith.text.ar}</div>
      <div class="hadith-translation">${hadith.text[this.currentLanguage]}</div>
      <div class="hadith-source">${hadith.source[this.currentLanguage]} - ${hadith.narrator}</div>
    `;
  }

  loadRandomHadith() {
    this.currentHadithIndex = Math.floor(Math.random() * islamicData.hadith.length);
    this.loadHadith();
  }

  loadDailyTip() {
    const tip = islamicData.dailyTips[this.currentTipIndex];
    const container = document.getElementById('tips-content');
    
    container.innerHTML = `
      <div class="tip-icon">💡</div>
      <div class="tip-text ${this.currentLanguage === 'ar' ? 'font-arabic' : ''}">${tip.tip[this.currentLanguage]}</div>
    `;
  }

  incrementTasbeeh() {
    this.tasbeehCount++;
    document.getElementById('counter-value').textContent = this.tasbeehCount;
    
    // Add animation effect
    const counter = document.getElementById('counter-value');
    counter.style.transform = 'scale(1.2)';
    setTimeout(() => {
      counter.style.transform = 'scale(1)';
    }, 150);
  }

  resetTasbeeh() {
    this.tasbeehCount = 0;
    document.getElementById('counter-value').textContent = this.tasbeehCount;
  }

  changePhrase(phrase) {
    this.currentPhrase = phrase;
    document.getElementById('current-phrase').textContent = phrase;
    
    // Update phrase buttons
    document.querySelectorAll('.phrase-btn').forEach(btn => {
      btn.classList.remove('active');
    });
    document.querySelector(`[data-phrase="${phrase}"]`).classList.add('active');
  }

  setupQibla() {
    const statusElement = document.getElementById('qibla-status');
    const t = islamicData.translations[this.currentLanguage];
    
    if (navigator.geolocation) {
      statusElement.textContent = t.findingLocation;
      
      navigator.geolocation.getCurrentPosition(
        (position) => {
          this.userLocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
          this.calculateQibla();
          statusElement.textContent = t.qiblaFound;
        },
        (error) => {
          statusElement.textContent = t.locationError;
          console.error('Geolocation error:', error);
        }
      );
    } else {
      statusElement.textContent = t.locationError;
    }
  }

  calculateQibla() {
    if (!this.userLocation) return;

    // Kaaba coordinates
    const kaaba = { lat: 21.4225, lng: 39.8262 };
    
    // Calculate bearing to Kaaba
    const lat1 = this.userLocation.lat * Math.PI / 180;
    const lat2 = kaaba.lat * Math.PI / 180;
    const deltaLng = (kaaba.lng - this.userLocation.lng) * Math.PI / 180;
    
    const y = Math.sin(deltaLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(deltaLng);
    
    this.qiblaDirection = Math.atan2(y, x) * 180 / Math.PI;
    this.qiblaDirection = (this.qiblaDirection + 360) % 360;
    
    // Update compass
    const arrow = document.getElementById('qibla-arrow');
    arrow.style.transform = `translate(-50%, -50%) rotate(${this.qiblaDirection}deg)`;
  }

  loadPrayerTimes() {
    const container = document.getElementById('prayer-content');
    const t = islamicData.translations[this.currentLanguage];
    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();
    
    const prayers = [
      { name: t.fajr, time: islamicData.prayerTimes.fajr.defaultTime, icon: islamicData.prayerTimes.fajr.icon, key: 'fajr' },
      { name: t.sunrise, time: islamicData.prayerTimes.sunrise.defaultTime, icon: islamicData.prayerTimes.sunrise.icon, key: 'sunrise' },
      { name: t.dhuhr, time: islamicData.prayerTimes.dhuhr.defaultTime, icon: islamicData.prayerTimes.dhuhr.icon, key: 'dhuhr' },
      { name: t.asr, time: islamicData.prayerTimes.asr.defaultTime, icon: islamicData.prayerTimes.asr.icon, key: 'asr' },
      { name: t.maghrib, time: islamicData.prayerTimes.maghrib.defaultTime, icon: islamicData.prayerTimes.maghrib.icon, key: 'maghrib' },
      { name: t.isha, time: islamicData.prayerTimes.isha.defaultTime, icon: islamicData.prayerTimes.isha.icon, key: 'isha' }
    ];

    // Find next prayer
    let nextPrayer = null;
    for (const prayer of prayers) {
      const [hours, minutes] = prayer.time.split(':').map(Number);
      const prayerTime = hours * 60 + minutes;
      if (currentTime < prayerTime) {
        nextPrayer = prayer.key;
        break;
      }
    }
    if (!nextPrayer) nextPrayer = 'fajr'; // Next day's Fajr

    container.innerHTML = '';
    
    prayers.forEach(prayer => {
      const item = document.createElement('div');
      item.className = `prayer-item ${prayer.key === nextPrayer ? 'current' : ''}`;
      
      item.innerHTML = `
        <div class="prayer-info">
          <span class="prayer-icon">${prayer.icon}</span>
          <div>
            <div class="prayer-name">${prayer.name}</div>
            ${prayer.key === nextPrayer ? `<div style="font-size: 0.75rem; color: var(--primary-color); font-weight: 600;">${t.nextPrayer}</div>` : ''}
          </div>
        </div>
        <div class="prayer-time">${prayer.time}</div>
      `;
      
      container.appendChild(item);
    });
  }

  updateDateTime() {
    const now = new Date();
    const dateStr = now.toLocaleDateString(this.currentLanguage === 'ar' ? 'ar-SA' : 'en-US');
    const dateElement = document.getElementById('current-date');
    if (dateElement) {
      const t = islamicData.translations[this.currentLanguage];
      dateElement.textContent = `${t.today} - ${dateStr}`;
    }
  }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new IslamicApp();
});
