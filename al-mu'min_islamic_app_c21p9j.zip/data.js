// Islamic App Data
const islamicData = {
  translations: {
    en: {
      appTitle: "Al-Mu'min",
      appSubtitle: "Your Islamic Companion",
      azkar: "Azkar",
      hadith: "Hadith",
      tips: "Tips",
      tasbeeh: "Tasbeeh",
      qibla: "Qibla",
      prayer: "Prayer",
      settings: "Settings",
      morning: "Morning",
      evening: "Evening",
      general: "General",
      repetitions: "repetitions",
      language: "Language",
      darkMode: "Dark Mode",
      darkModeDesc: "Toggle dark/light theme",
      notifications: "Notifications",
      notificationsDesc: "Daily tips and reminders",
      today: "Today",
      prayerTimes: "Prayer Times",
      qiblaDirection: "Qibla Direction",
      dailyTips: "Daily Tips",
      findingLocation: "Finding your location...",
      qiblaFound: "Qibla direction found",
      locationError: "Location access denied",
      fajr: "Fajr",
      sunrise: "Sunrise", 
      dhuhr: "Dhuhr",
      asr: "Asr",
      maghrib: "Maghrib",
      isha: "Isha",
      nextPrayer: "Next Prayer"
    },
    ar: {
      appTitle: "المؤمن",
      appSubtitle: "رفيقك الإسلامي",
      azkar: "أذكار",
      hadith: "حديث",
      tips: "نصائح",
      tasbeeh: "تسبيح",
      qibla: "قبلة",
      prayer: "صلاة",
      settings: "إعدادات",
      morning: "الصباح",
      evening: "المساء",
      general: "عامة",
      repetitions: "مرات",
      language: "اللغة",
      darkMode: "الوضع المظلم",
      darkModeDesc: "تبديل المظهر المظلم/الفاتح",
      notifications: "الإشعارات",
      notificationsDesc: "نصائح وتذكيرات يومية",
      today: "اليوم",
      prayerTimes: "أوقات الصلاة",
      qiblaDirection: "اتجاه القبلة",
      dailyTips: "نصائح يومية",
      findingLocation: "البحث عن موقعك...",
      qiblaFound: "تم العثور على اتجاه القبلة",
      locationError: "تم رفض الوصول للموقع",
      fajr: "الفجر",
      sunrise: "الشروق",
      dhuhr: "الظهر",
      asr: "العصر",
      maghrib: "المغرب",
      isha: "العشاء",
      nextPrayer: "الصلاة التالية"
    },
    fr: {
      appTitle: "Al-Mu'min",
      appSubtitle: "Votre Compagnon Islamique",
      azkar: "Azkar",
      hadith: "Hadith",
      tips: "Conseils",
      tasbeeh: "Tasbeeh",
      qibla: "Qibla",
      prayer: "Prière",
      settings: "Paramètres",
      morning: "Matin",
      evening: "Soir",
      general: "Général",
      repetitions: "répétitions",
      language: "Langue",
      darkMode: "Mode Sombre",
      darkModeDesc: "Basculer le thème sombre/clair",
      notifications: "Notifications",
      notificationsDesc: "Conseils et rappels quotidiens",
      today: "Aujourd'hui",
      prayerTimes: "Heures de Prière",
      qiblaDirection: "Direction de la Qibla",
      dailyTips: "Conseils Quotidiens",
      findingLocation: "Recherche de votre position...",
      qiblaFound: "Direction de la Qibla trouvée",
      locationError: "Accès à la localisation refusé",
      fajr: "Fajr",
      sunrise: "Lever du soleil",
      dhuhr: "Dhuhr",
      asr: "Asr",
      maghrib: "Maghrib",
      isha: "Isha",
      nextPrayer: "Prochaine Prière"
    },
    ru: {
      appTitle: "Аль-Муъмин",
      appSubtitle: "Ваш исламский спутник",
      azkar: "Азкар",
      hadith: "Хадис",
      tips: "Советы",
      tasbeeh: "Тасбих",
      qibla: "Кибла",
      prayer: "Молитва",
      settings: "Настройки",
      morning: "Утро",
      evening: "Вечер",
      general: "Общие",
      repetitions: "повторений",
      language: "Язык",
      darkMode: "Темный режим",
      darkModeDesc: "Переключить темную/светлую тему",
      notifications: "Уведомления",
      notificationsDesc: "Ежедневные советы и напоминания",
      today: "Сегодня",
      prayerTimes: "Время Молитв",
      qiblaDirection: "Направление Киблы",
      dailyTips: "Ежедневные Советы",
      findingLocation: "Поиск вашего местоположения...",
      qiblaFound: "Направление Киблы найдено",
      locationError: "Доступ к местоположению запрещен",
      fajr: "Фаджр",
      sunrise: "Восход",
      dhuhr: "Зухр",
      asr: "Аср",
      maghrib: "Магриб",
      isha: "Иша",
      nextPrayer: "Следующая Молитва"
    }
  },

  azkar: {
    morning: [
      {
        id: 1,
        title: {
          ar: "أعوذ بالله من الشيطان الرجيم",
          en: "I seek refuge in Allah from Satan the accursed",
          fr: "Je cherche refuge auprès d'Allah contre Satan le maudit",
          ru: "Прибегаю к защите Аллаха от проклятого шайтана"
        },
        text: {
          ar: "أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ",
          en: "A'udhu billahi min ash-shaytani'r-rajim",
          fr: "A'udhu billahi min ash-shaytani'r-rajim",
          ru: "А'узу биллахи мин аш-шайтани-р-раджим"
        },
        repetitions: 3
      },
      {
        id: 2,
        title: {
          ar: "آية الكرسي",
          en: "Ayat al-Kursi",
          fr: "Verset du Trône",
          ru: "Аят аль-Курси"
        },
        text: {
          ar: "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ",
          en: "Allah - there is no deity except Him, the Ever-Living, the Sustainer of existence. Neither drowsiness overtakes Him nor sleep. To Him belongs whatever is in the heavens and whatever is on the earth.",
          fr: "Allah - il n'y a de divinité que Lui, le Vivant, Celui qui subsiste par lui-même. Ni somnolence ni sommeil ne Le saisissent. A Lui appartient tout ce qui est dans les cieux et sur la terre.",
          ru: "Аллах - нет божества, кроме Него, Живого, Поддерживающего бытие. Не овладевает Им ни дремота, ни сон. Ему принадлежит то, что в небесах и на земле."
        },
        repetitions: 1
      },
      {
        id: 3,
        title: {
          ar: "سبحان الله وبحمده",
          en: "Glory be to Allah and praise be to Him",
          fr: "Gloire à Allah et louange à Lui",
          ru: "Слава Аллаху и хвала Ему"
        },
        text: {
          ar: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
          en: "Subhan Allah wa bihamdihi",
          fr: "Subhan Allah wa bihamdihi",
          ru: "Субхан Аллахи ва бихамдихи"
        },
        repetitions: 100
      }
    ],
    evening: [
      {
        id: 4,
        title: {
          ar: "أعوذ بكلمات الله التامات",
          en: "I seek refuge in the perfect words of Allah",
          fr: "Je cherche refuge dans les paroles parfaites d'Allah",
          ru: "Прибегаю к защите совершенных слов Аллаха"
        },
        text: {
          ar: "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ",
          en: "A'udhu bi kalimat Allah at-tammat min sharri ma khalaq",
          fr: "A'udhu bi kalimat Allah at-tammat min sharri ma khalaq",
          ru: "А'узу би калимат Аллахи-т-таммат мин шарри ма халяк"
        },
        repetitions: 3
      },
      {
        id: 5,
        title: {
          ar: "الحمد لله رب العالمين",
          en: "Praise be to Allah, Lord of the worlds",
          fr: "Louange à Allah, Seigneur des mondes",
          ru: "Хвала Аллаху, Господу миров"
        },
        text: {
          ar: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
          en: "Alhamdulillahi rabbil alameen",
          fr: "Alhamdulillahi rabbil alameen",
          ru: "Альхамду лиллахи рабби-ль-алямин"
        },
        repetitions: 10
      }
    ],
    general: [
      {
        id: 6,
        title: {
          ar: "استغفار",
          en: "Seeking Forgiveness",
          fr: "Demande de Pardon",
          ru: "Просьба о прощении"
        },
        text: {
          ar: "أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ الَّذِي لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ",
          en: "Astaghfirullah al-azeem alladhi la ilaha illa huwa al-hayy al-qayyum wa atubu ilayh",
          fr: "Astaghfirullah al-azeem alladhi la ilaha illa huwa al-hayy al-qayyum wa atubu ilayh",
          ru: "Астагфируллах аль-азым аллязи ля иляха илля хува аль-хайй аль-каййум ва атубу иляйх"
        },
        repetitions: 100
      }
    ]
  },

  hadith: [
    {
      id: 1,
      text: {
        ar: "إنما الأعمال بالنيات وإنما لكل امرئ ما نوى",
        en: "Actions are but by intention and every man shall have but that which he intended",
        fr: "Les actions ne valent que par les intentions et chacun n'aura que ce qu'il a eu l'intention de faire",
        ru: "Поистине, дела оцениваются по намерениям, и каждому человеку достанется лишь то, что он намеревался обрести"
      },
      source: {
        ar: "صحيح البخاري",
        en: "Sahih al-Bukhari",
        fr: "Sahih al-Bukhari",
        ru: "Сахих аль-Бухари"
      },
      narrator: "عمر بن الخطاب"
    },
    {
      id: 2,
      text: {
        ar: "من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت",
        en: "Whoever believes in Allah and the Last Day should speak good or remain silent",
        fr: "Quiconque croit en Allah et au Jour dernier, qu'il dise du bien ou qu'il se taise",
        ru: "Кто верует в Аллаха и в Последний день, пусть говорит благое или молчит"
      },
      source: {
        ar: "صحيح البخاري",
        en: "Sahih al-Bukhari",
        fr: "Sahih al-Bukhari",
        ru: "Сахих аль-Бухари"
      },
      narrator: "أبو هريرة"
    },
    {
      id: 3,
      text: {
        ar: "المؤمن للمؤمن كالبنيان يشد بعضه بعضاً",
        en: "The believer to another believer is like a building whose different parts enforce each other",
        fr: "Le croyant envers un autre croyant est comme un bâtiment dont les différentes parties se renforcent mutuellement",
        ru: "Верующий по отношению к другому верующему подобен зданию, части которого укрепляют друг друга"
      },
      source: {
        ar: "صحيح البخاري",
        en: "Sahih al-Bukhari",
        fr: "Sahih al-Bukhari",
        ru: "Сахих аль-Бухари"
      },
      narrator: "أبو موسى الأشعري"
    }
  ],

  dailyTips: [
    {
      id: 1,
      tip: {
        ar: "ابدأ يومك بذكر الله واستغفاره، فإن في ذلك بركة وطمأنينة للقلب",
        en: "Start your day with remembrance of Allah and seeking His forgiveness, for there is blessing and peace for the heart in that",
        fr: "Commencez votre journée par le rappel d'Allah et en demandant Son pardon, car il y a une bénédiction et une paix pour le cœur dans cela",
        ru: "Начинайте свой день с поминания Аллаха и просьбы о Его прощении, ибо в этом есть благословение и покой для сердца"
      }
    },
    {
      id: 2,
      tip: {
        ar: "الصلاة في وقتها نور للقلب وراحة للروح، فحافظ عليها",
        en: "Prayer at its time is light for the heart and rest for the soul, so maintain it",
        fr: "La prière à son heure est une lumière pour le cœur et un repos pour l'âme, alors maintenez-la",
        ru: "Молитва в свое время - это свет для сердца и покой для души, поэтому соблюдайте ее"
      }
    },
    {
      id: 3,
      tip: {
        ar: "اقرأ القرآن يومياً ولو آية واحدة، فإن القليل الدائم خير من الكثير المنقطع",
        en: "Read the Quran daily, even if just one verse, for a little done consistently is better than a lot done sporadically",
        fr: "Lisez le Coran quotidiennement, ne serait-ce qu'un verset, car un peu fait de manière constante vaut mieux que beaucoup fait de manière sporadique",
        ru: "Читайте Коран ежедневно, хотя бы один аят, ибо малое, совершаемое постоянно, лучше многого, совершаемого от случая к случаю"
      }
    },
    {
      id: 4,
      tip: {
        ar: "تذكر الموت كثيراً، فإنه يطهر القلب ويزهد في الدنيا",
        en: "Remember death often, for it purifies the heart and makes one detached from worldly matters",
        fr: "Souvenez-vous souvent de la mort, car elle purifie le cœur et détache des affaires mondaines",
        ru: "Часто вспоминайте о смерти, ибо это очищает сердце и отвращает от мирского"
      }
    },
    {
      id: 5,
      tip: {
        ar: "أكثر من الدعاء، فإنه عبادة وصلة بينك وبين الله",
        en: "Make frequent supplications, for it is worship and a connection between you and Allah",
        fr: "Multipliez les invocations, car c'est un acte d'adoration et un lien entre vous et Allah",
        ru: "Чаще обращайтесь с мольбами, ибо это поклонение и связь между вами и Аллахом"
      }
    }
  ],

  tasbeehPhrases: [
    { ar: "سبحان الله", en: "Subhan Allah", meaning: "Glory be to Allah" },
    { ar: "الحمد لله", en: "Alhamdulillah", meaning: "Praise be to Allah" },
    { ar: "الله أكبر", en: "Allahu Akbar", meaning: "Allah is Greatest" },
    { ar: "لا إله إلا الله", en: "La ilaha illa Allah", meaning: "There is no god but Allah" }
  ],

  prayerTimes: {
    fajr: { icon: "🌅", defaultTime: "05:30" },
    sunrise: { icon: "☀️", defaultTime: "06:45" },
    dhuhr: { icon: "🌞", defaultTime: "12:30" },
    asr: { icon: "🌤️", defaultTime: "15:45" },
    maghrib: { icon: "🌅", defaultTime: "18:15" },
    isha: { icon: "🌙", defaultTime: "19:30" }
  }
};
