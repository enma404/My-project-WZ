import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const getRandomHadith = query({
  args: {},
  handler: async (ctx) => {
    const allHadith = await ctx.db.query("hadith").collect();
    if (allHadith.length === 0) return null;
    
    const randomIndex = Math.floor(Math.random() * allHadith.length);
    return allHadith[randomIndex];
  },
});

export const getAllHadith = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("hadith").collect();
  },
});

export const seedHadith = mutation({
  args: {},
  handler: async (ctx) => {
    const existingHadith = await ctx.db.query("hadith").first();
    if (existingHadith) return;

    const hadithData = [
      {
        text: {
          ar: "إنما الأعمال بالنيات وإنما لكل امرئ ما نوى",
          en: "Actions are but by intention and every man shall have but that which he intended",
          fr: "Les actions ne valent que par les intentions et chacun n'aura que ce qu'il a eu l'intention de faire",
          ru: "Поистине, дела оцениваются по намерениям, и каждому человеку достанется лишь то, что он намеревался обрести"
        },
        source: {
          ar: "صحيح البخاري",
          en: "Sahih al-Bukhari",
          fr: "Sahih al-Bukhari",
          ru: "Сахих аль-Бухари"
        },
        narrator: "عمر بن الخطاب",
        isAuthentic: true,
        category: "intentions"
      },
      {
        text: {
          ar: "من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت",
          en: "Whoever believes in Allah and the Last Day should speak good or remain silent",
          fr: "Quiconque croit en Allah et au Jour dernier, qu'il dise du bien ou qu'il se taise",
          ru: "Кто верует в Аллаха и в Последний день, пусть говорит благое или молчит"
        },
        source: {
          ar: "صحيح البخاري",
          en: "Sahih al-Bukhari",
          fr: "Sahih al-Bukhari",
          ru: "Сахих аль-Бухари"
        },
        narrator: "أبو هريرة",
        isAuthentic: true,
        category: "speech"
      }
    ];

    for (const hadith of hadithData) {
      await ctx.db.insert("hadith", hadith);
    }
  },
});
