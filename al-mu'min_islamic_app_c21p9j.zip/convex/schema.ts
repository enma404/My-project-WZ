import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  azkar: defineTable({
    category: v.string(), // "morning", "evening", "general"
    title: v.object({
      ar: v.string(),
      en: v.string(),
      fr: v.string(),
      ru: v.string(),
    }),
    text: v.object({
      ar: v.string(),
      en: v.string(),
      fr: v.string(),
      ru: v.string(),
    }),
    transliteration: v.optional(v.string()),
    repetitions: v.optional(v.number()),
    order: v.number(),
  }).index("by_category", ["category"]),

  hadith: defineTable({
    text: v.object({
      ar: v.string(),
      en: v.string(),
      fr: v.string(),
      ru: v.string(),
    }),
    source: v.object({
      ar: v.string(),
      en: v.string(),
      fr: v.string(),
      ru: v.string(),
    }),
    narrator: v.string(),
    isAuthentic: v.boolean(),
    category: v.optional(v.string()),
  }),

  dailyTips: defineTable({
    tip: v.object({
      ar: v.string(),
      en: v.string(),
      fr: v.string(),
      ru: v.string(),
    }),
    date: v.string(), // YYYY-MM-DD format
    category: v.optional(v.string()),
  }).index("by_date", ["date"]),

  userSettings: defineTable({
    userId: v.id("users"),
    language: v.string(), // "ar", "en", "fr", "ru"
    darkMode: v.boolean(),
    notificationsEnabled: v.boolean(),
    location: v.optional(v.object({
      latitude: v.number(),
      longitude: v.number(),
      city: v.string(),
    })),
  }).index("by_user", ["userId"]),

  tasbeehSessions: defineTable({
    userId: v.id("users"),
    count: v.number(),
    phrase: v.string(),
    date: v.string(),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
